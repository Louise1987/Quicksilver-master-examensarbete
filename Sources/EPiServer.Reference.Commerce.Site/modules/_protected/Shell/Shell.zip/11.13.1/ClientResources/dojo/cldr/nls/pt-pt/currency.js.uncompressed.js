define(
"dojo/cldr/nls/pt-pt/currency", //begin v1.x content
{
	"CAD_displayName": "Dólar canadiano",
	"USD_displayName": "Dólar dos Estados Unidos"
}
//end v1.x content
);